<?php

// Configurações de credenciais
$server = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'aula_formulario';

// Conexão com o banco de dados
$conn = new mysqli($server, $usuario, $senha, $banco);

// Verificar conexão
if($conn->connect_error) {
    die("Falha ao se conectar com banco de dados! ".$conn->connect_error);
}

?>